from distutils.core import setup

setup(
    name='btcelib',
    version='1.1dev',
    packages=['btcelib', ],
    license='MIT',
    long_description=open('readme').read(),
)
